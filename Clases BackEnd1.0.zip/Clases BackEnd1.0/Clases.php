<?php
	class Cliente{
		//Atributos
		public $Nombre;
		public $NoIdentidad;
		
		public function __construct($Nombre, $NoIdentidad){
        $this->Nombre = $Nombre;
        $this->NoIdentidad = $NoIdentidad;
    }

	}
	class Instructor{
		//Atributos
		public $Nombre;
		public $NoIdentidad;
		public $Curso;

		public function __construct($Nombre, $NoIdentidad,$Curso){
        $this->Nombre = $Nombre;
        $this->NoIdentidad = $NoIdentidad;
        $this->Curso=$Curso
    }

		}
	}
	class Curso{
		//Atributos
		public $Nombre;
		public $Codigo;
		public $NumeroAlumnos;
		public $Instructor;
		
		public function __construct($Nombre, $Codigo,$NumeroAlumnos,$Instructor){
        $this->Nombre = $Nombre;
        $this->Codigo = $Codigo;
        $this->NumeoAlumnos = $NumeroAlumnos;
        $this->Instructor = $Instructor;
    }
	}
	class Cliente{
		//Atributos
		public $Nombre;
		public $NoIdentidad;
		
		public function Hablar(){

		}
	}
	class Alumno{
		//Atributos
		public $Nombre;
		public $NoIdentidad;
		public $Certificado;
		
		public function __construct($Nombre, $NoIdentidad,$Certificado){
        $this->Nombre = $Nombre;
        $this->NoIdentidad = $NoIdentidad;
        $this->Certificado = $Certificado;
    }



	
?>